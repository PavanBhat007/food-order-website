import React from 'react'

export default function Footer() {
  return (
    <>
        <footer>
            <p className="text-center">
                Food Ordering website created in 2024 (WSA MERN Internship) - UNLICENSED
            </p>
        </footer>
    </>
  )
}
